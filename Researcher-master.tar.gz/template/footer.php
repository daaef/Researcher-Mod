<?php /**
 * Created by IntelliJ IDEA.
 * User: OLAYIWOLE
 * Date: 10/09/2017
 * Time: 14:50
 */ ?>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md">
                <ul class="footer-nav">
                    <?php nav_footer($db_conn); ?>
                    <li><p>Contact Us: hello@researcher.ng,</p></li>
                    <li><p>+2347068211304</p></li>
                </ul>
            </div>
            <div class="col-md">
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/researcherdotng" style="color: #ddd;"><i class="ion-social-facebook"></i></a></li>
                    <li><a href="https://www.twitter.com/researcherdotng?s=03" style="color: #ddd;"><i class="ion-social-twitter"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container">
        <p>
Copyright &copy; Researcher.ng 2017
</p>
    </div>
</footer>