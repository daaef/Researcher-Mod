# Researcher
ResearcherNG website. This is the landing page for the organisation.

Future modification shall be carried out in the next iteration.
